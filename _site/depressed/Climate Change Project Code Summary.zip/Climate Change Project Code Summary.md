# Climate Change Project Code Summary
Last update: 2018/8/31 增加了climate change effects的代码和画图。增加了一个修改的程序，直接读取.nc文件生成vairance和covariance。

## Procedures
我之前的code主要分为6个步骤
- data_download: download data
- data_to_csv: convert the `nc` file to `csv`
- data_to_new: clean the data
- data_to_split: split the data by year
- data_des: compute the variance and mean
- stat_plot: draw the plot

你可以根据自己的需求进行更改，但是我建议你不要存成csv格式的文件，因为这样的读取不是很方便。
我在后面附了一个新的代码，可以直接从.nc文件出发生成variance和covariance
## Important functions
```R
# Use spectral density approach to compute the variance of mean and quantile
# Input a time series Y.data
# Return the quantile and its variance
SpectralQuanVar = function(Y.data, q = 0.9){
  Y.data = as.numeric(na.omit(Y.data))
  if(length(Y.data) <= 2){
    return(c(NA, NA))
  }
  if(range(Y.data)[1] == range(Y.data)[2]){
    return(c(Y.data[1], 0))
  }
  
  k <- function(z, h) {
    dnorm((z)/h)/h
  }
  
  G <- function(x){
    pnorm(x)
  }
  
  F.n.h <-function(x,Y,h,p){
    n <- length(Y)
    
    (1/n *sum(G((x-Y)/h)) - p)**2
  }
  
  
  v.pvalue <- function(p.value, Y){
    h = density(Y, kernel = "gaussian")$bw
    accuracy = (max(Y) - min(Y)) / 100000
    ans <- optimize(F.n.h ,c(min(Y),max(Y)),tol = accuracy, p = p.value
                    ,h = h,Y=Y.data)  
    return(ans$minimum)
  }
  
  v.p <- v.pvalue(q, Y.data)
  #return(v.p)
  ##### 计算Z_t
  h = density(Y.data, kernel = "gaussian")$bw
  Z.t <- G((v.p-Y.data)/h)
  
  n = length(Z.t)
  
  fft.out = abs(fft(Z.t))^2 / n
  I.w.j <- c(fft.out[seq((floor(n / 2) + 1), 2, -1)], fft.out[2:(floor(n / 2) + 1)])
  I.w.j = I.w.j + 0.000000001 #remove inf
  W.j <- log(I.w.j/(2*pi)) + 0.57721
  w.j = c(seq(-floor(n / 2), -1, 1), seq(1, floor(n / 2)))
  
  library(np)
  bw <- npregbw(W.j ~ w.j)
  m.0 <- npreg(bw, exdat = 0)$mean
  
  Phi.0 <- exp(m.0)
  
  
  ##计算在v.p这一点的核密度
  f.hat <- function(v.p){
    h <- density(x=Y.data)$bw
    return(1/n * sum(unlist(lapply(v.p - Y.data, k, h))))
  }
  
  v.p.std <- sqrt(2*pi*Phi.0/n/f.hat(v.p)**2)
  return(c(v.p,v.p.std))
}

# Input a time series Y.t
# Return its variance
SpectralMeanVar = function(Y.t){
  Y.t = as.numeric(na.omit(Y.t))
  if(length(Y.t) <= 2){
    return(NA)
  }
  # Get the spectral density of Y_t
  #Y.t <- rnorm(1000)
  n = length(Y.t)
  
  fft.out = abs(fft(Y.t))^2 / n
  I.w.j <- c(fft.out[seq((floor(n / 2) + 1), 2, -1)], fft.out[2:(floor(n / 2) + 1)])
  I.w.j = I.w.j + 0.000000001 #remove inf
  W.j <- log(I.w.j/(2*pi)) + 0.57721
  w.j = c(seq(-floor(n / 2), -1, 1), seq(1, floor(n / 2)))
  
  library(np)
  bw <- npregbw(W.j ~ w.j)
  m.0 <- npreg(bw, exdat = 0)$mean
  
  Phi.0 <- exp(m.0)
  mean.var = sqrt(2 * pi * Phi.0 / n)
  return(mean.var)
}
```

```R
# FDR controlling(False discovery rate controlling)
# Ziping 2017-05-31
p = 1 - pnorm(abs(t$t))

# Input: p is the p-values to be tested, q is the level of significance
# Return: A array, 0 for not significant and 1 for signigicant
FDR = function(p, q){
  
  index <- read.csv("/home/master/ecmwf/combined/sea.csv")[, 1]
  
  m0 = length(p)
  land = seq(1, m0)[-index]
  
  p.value = p[-index]
  
  m =  length(p.value)# number of hypothesis
  
  p.order = order(p.value) # ordered
  
  l = seq(1, m, 1)
  m.test = p.value[p.order] / l * m / q
  k = max(which(m.test <= 1)) # number of rejection
  
  out = rep(0, m0)
  out[land[p.order[1:k]]] = 1
  return(out)
}
```

下面这个代码是我后面修改的，直接从.nc文件出发计算variance and covariance
```r
# 读取.nc文件，生成每个变量每年的mean和variance，存储为.csv文件
library(lubridate)
library(ncdf4)

setwd("/home/panhao/mnt/data")
ncname <- "sfc.nc" 
ncin <- nc_open(ncname)
source("for_prep/nc_reader.r")

SpectralMeanVar = function(Y.t){
  Y.t = as.numeric(na.omit(Y.t))
  if(length(Y.t) <= 2){
    return(NA)
  }
  # Get the spectral density of Y_t
  #Y.t <- rnorm(1000)
  n = length(Y.t)
  
  fft.out = abs(fft(Y.t))^2 / n
  I.w.j <- c(fft.out[seq((floor(n / 2) + 1), 2, -1)], fft.out[2:(floor(n / 2) + 1)])
  I.w.j = I.w.j + 0.000000001 #remove inf
  W.j <- log(I.w.j/(2*pi)) + 0.57721
  w.j = c(seq(-floor(n / 2), -1, 1), seq(1, floor(n / 2)))
  
  library(np)
  bw <- npregbw(W.j ~ w.j)
  m.0 <- npreg(bw, exdat = 0)$mean
  
  Phi.0 <- exp(m.0)
  mean.var = sqrt(2 * pi * Phi.0 / n)
  return(mean.var)
}

year1 = seq(1979, 1997, 1)
year2 = seq(1998, 2016, 1)
months = seq(1, 12, 1)

lat = seq(42.5, 33, -0.25)
lon = seq(113, 119.5, 0.25)

for(m in seq(5, 12, 1)){
  aaa = 1
  for(y1 in year1){
    tmean = list()
    tvariance = list()
    y2 = y1 + 19
    for(la in lat){
      for(lo in lon){
        t1 = nc_reader(ncin, -1, sprintf("%d-%02d-01 00:00:00", y1, m),
                       sprintf("%d-%02d-28 00:00:00", y1, m), la, lo, "tp")
        t2 = nc_reader(ncin, -1, sprintf("%d-%02d-01 00:00:00", y2, m),
                       sprintf("%d-%02d-28 00:00:00", y2, m), la, lo, "tp")
        t = t2 - t1
        tm = mean(t)
        tv = SpectralMeanVar(t)
        tmean = append(tmean, tm)
        tvariance = append(tvariance, tv)
      }
    }
    tmean = t(data.frame(tmean))
    tvariance = t(data.frame(tvariance))
    write.csv(tmean, sprintf("for_prep/mean/%d_%d.csv", y1, m), row.names = F)
    write.csv(tvariance, sprintf("for_prep/var/%d_%d.csv", y1, m), row.names = F)
  }
}


```
References: 
- Nonparametric Inference of Value at Risk for Dependent Financial (Chen & Tang, 2005)
- Controlling the false discovery rate: a practical and powerful approach to multiple testing (Benjamini, 1995)

### Change Map
![](Climate%20Change%20Project%20Code%20Summary/mean_d2m.jpg)
```R
# This code is for ploting the map
# 读取.csv的mean和variance数据，生成change plot
# last updated by Ziping on 2017-10-10

type1 = c("avg", "var")
type2 = c("q90", "q90Var")

# region
library(ggplot2)
library(reshape2)
library(RColorBrewer)
#library(maptools)
library(ggmap)
library(maps)
library(readxl)
library(dplyr)

# ------加载区划边界线-----
DownSample = function(x){
  row = ceiling(x/27)
  col = x - (row - 1) * 27
  
  if(row%%2 == 1 && col%%2 == 1){
    return(((row + 1) / 2)*14 + (col + 1) / 2)
  }
  return(-1)
}

index <- read.csv("/home/panhao/mnt/master/ecmwf/support file/sea.csv")[, 1]
index = sapply(index, FUN = DownSample)
index = index[which(index != -1)]
index = c(98, 109, 110,111, index)
index = c(98, 109, 110, 111, 112, 123, 124, 125, 126, 138, 139, 140, 153, 154, 167, 168, 210, 224, 238)
FDR = function(p, q){
  # p is the p-values to be tested ,q is the level of significance
  
  m0 = length(p)
  land = seq(1, m0)[-index]
  
  p.value = p[-index]
  
  m =  length(p.value)# number of hypothesis
  
  p.order = order(p.value) # ordered
  
  l = seq(1, m, 1)
  
  
  m.test = p.value[p.order] / l * m / q
  k = max(which(m.test <= 1)) # number of rejection
  
  out = rep(0, m0)
  
  if(k == -Inf)
    return(out)
  
  out[land[p.order[1:k]]] = 1
  return(out)
}

load("/home/panhao/mnt/master/ecmwf/support file/region/bjgr.RData")
bjgr1 = dplyr::filter(bjgr, is.element(bjgr$id, c(1, 26, 9, 18, 22, 11, 24, 0, 14)))
bjgr1 = data.frame(bjgr)
for(i in 1:5){
  bjgr1 = bjgr1[which(bjgr1$order %% 2 == 0), ]
  bjgr1$order = bjgr1$order / 2
}
region = geom_path(data=bjgr1,aes(x=long,y=lat,group=group), colour= "black", size =0.3,inherit.aes=TRUE)

limit = coord_fixed(ylim = c(33, 42.5), xlim = c(113, 119.5))
setwd("/home/panhao/mnt/data/stat_comb")

# 设置绘图基本要素
scale = c(-7, -3.5, -1.96, 0, 1.96, 3.5, 7)
color = c("black", "blue", "green", "white", "yellow", "orange", "red")
mycolors<-brewer.pal(10,"Spectral")
mycolors = c(mycolors[10:6], "white", mycolors[5:1])
color = mycolors

variable = c("sp", "bld", "blh", "t2m", "d2m")
var_num = length(variable)

library(dplyr)
for(ttvar in 1:var_num){
  all_dm = NA
  all_t.sig = NA
  all_t.cont = NA
  tmax = 0
  for(block in seq(1, 12, 1)){
    print(block)
    type = type1
    #Two periods
    y1 = seq(1979, 1997, 1)
    y = list(y1)
    
    var.num = 58
    grid.num = 1053
    
    NAto0 = function(v){
      v[which(is.na(v))] = 0
      return(v)
    }
    #mean for different periods
    
    my.sum = function(x){
      x = as.character(x)
      x = as.numeric(unlist(strsplit(x, "_")))
      return(sum(x))
    }
    my.count = function(x){
      x = as.character(x)
      x = as.numeric(unlist(strsplit(x, "_")))
      return(length(x))
    }
    mean = NA
    for(j in 1:length(y)){
      com.num = matrix(0, nrow = var.num, ncol = grid.num)
      for(i in y[[j]]){
        if(i == y[[j]][1]){
          tmean = read.csv(paste0(type[1], "_", i, "_", block, ".csv"))
          com.num = com.num + as.numeric(!is.na(tmean))
          tmean = data.frame(lapply(tmean, NAto0))
        }
        else{
          temp = read.csv(paste0(type[1], "_", i, "_", block, ".csv"))
          com.num = com.num + as.numeric(!is.na(temp))
          temp = data.frame(lapply(temp, NAto0))
          tmean = tmean + temp
        }
      }
      tmean = tmean / com.num
      #tmean = tmean[325:1053, ]
      mean = rbind(mean, cbind(tmean, rep(j, dim(tmean)[1])))
    }
    colnames(mean)[length(mean)] = "period"
    mean = mean[-1, ]
    
    var = NA
    for(j in 1:length(y)){
      tvariance = list()
      variance = NA
      for(i in y[[j]]){
        tvariance = append(tvariance, list((read.csv(paste0(type[2], "_", i, "_", block, ".csv")) / 2)^2))
      }
      
      for(i in 1:dim(tmean)[2]){
        tvar = NA
        for(k in 1:length(y[[j]])){
          tvar = cbind(tvar, tvariance[[k]][, i])
        }
        tvar = tvar[, -1]
        not.na = rowSums(!is.na(tvar))
        tvar = sqrt(rowSums(tvar, na.rm = T) / not.na^2)
        variance = cbind(variance, tvar)
      }
      variance = cbind(variance[, -1], rep(j, length(tvar)))
      #variance = variance[325:1053, ]
      var = rbind(var, variance)
    }
    colnames(var) = colnames(mean)
    var = var[-1, ]
    variance = var
    variable = colnames(mean)[-dim(mean)[2]]
    
    tmax = max(c(tmax, max(abs(mean[, ttvar])) ))
    
    
    
    # 下采样
    num = seq(1, 27, 2)
    sel = c()
    for(lat in seq(1, 39, 2)){
      sel = c(sel, num + (lat - 1)*27)
    }
    sel = c(sel)#, sel + 2106)
    mean = mean[sel, ]
    variance = variance[sel, ]
    variable = colnames(mean)[-dim(mean)]
    
    # location
    #lat = seq(42.5, 32, -0.25)
    #lon = seq(113, 119.5, 0.25)
    #tloc = matrix(0.0, ncol = 2, nrow = 27*39)
    
    lat = seq(42.5, 32, -0.25)
    lon = seq(113, 119.5, 0.25)
    tloc = matrix(0.0, ncol = 2, nrow = 20*14)
    tid = 1
    for(i in seq(1, 39, 2)){
      for(j in seq(1, 27, 2)){
        tloc[tid, ] = c(lat[i], lon[j])
        tid = tid + 1
      }
    }
    loc = rbind(tloc)
    
    m = cbind(mean[, c(ttvar, dim(mean)[2])], loc)
    v = data.frame(cbind(variance[, c(ttvar, dim(mean)[2])], loc))
    
    #compute the difference avg between p1 and p4
    
    #t-value
    t = m
    t[, 1] = m[, 1] / v[, 1]
    t = data.frame(t)
    colnames(t) = c("t", "period", "lat", "lon")
    
    p = 1 - pnorm(abs(t$t))
    sig = which(FDR(p, 0.025) == 1)
    # mark contour
    t.cont = t
    t.cont[, 1] = -1
    t.cont[sig, 1] = 1
    
    colnames(t.cont) = c("t", "period", "lat", "lon")
    m_draw = m
    colnames(m_draw) = c("mu_climate", "period", "lat", "lon")
    
    month = rep(block, dim(m_draw)[1])
    m_draw = cbind(m_draw, month)
    m_draw[index, 1] = 0
    all_dm = rbind(all_dm, m_draw)
    
	  # mark significance
    t.sig = t.cont
    t.sig$t[which(t.cont[, 1] == 1)] = "*"
    t.sig$t[which(t.cont[, 1] == -1)] = ""
    t.sig = cbind(t.sig, month)
    all_t.sig = rbind(all_t.sig, t.sig)
    
    t.cont = cbind(t.cont, month)
    all_t.cont = rbind(all_t.cont, t.cont)
  }
  all_dm = all_dm[-1, ]
  all_t.sig = all_t.sig[-1, ]
  all_t.cont = all_t.cont[-1, ]
  tmax = tmax * 1.1
  
  colnames(all_t.cont)[1] = "t.cont"
  colnames(all_t.sig)[1] = "t.sig"
  all = cbind(all_dm, all_t.cont[1], all_t.sig[1])
  
  all$month = factor(all$month)
  levels(all$month) = c("Jan", "Feb", "Mar", "Apr", "May", "Jun",
                        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
  # tmax = max(abs(my_range[1, ttvar]), abs(my_range[2, ttvar])) * 1.2
  break.point1 = seq(-tmax, tmax, length.out = 7)
  break.point1 = signif(break.point1, 2)
  g1 = ggplot() +
    geom_tile(data = all, aes(x = lon, y = lat, fill = mu_climate))
  g1 = g1 + scale_fill_gradientn(colors = color,limits=c(min(break.point1),max(break.point1))
                                 ,guide = 'colourbar',breaks=break.point1)
  g1 = g1 + xlab("Longitude")  + ylab("Latitude") +
    theme(axis.text.x = element_text(size=rel(1.7),face = 'bold'),
                  axis.text.y = element_text(size=rel(1.7),face = 'bold'),
                  axis.title.x = element_text(size=rel(2),face = 'bold'),
                  axis.title.y = element_text(size=rel(2),face = 'bold'),
                  legend.text = element_text(size = rel(1), face = 'bold'),
                  #legend.title = element_text(size = rel(1), face = 'bold'),
                  legend.title=element_blank(),
                  legend.position = 'bottom',
                  legend.key.height=unit(5, "mm"),
                  legend.key.width=unit(35, "mm"), #图例符号的宽度
                  strip.text = element_text(size = rel(1.7), face = 'bold'),
                  strip.background = element_rect(fill = "white"))
  
  g1 = g1 + geom_text(data = all, aes(x=lon,y=lat, label = t.sig))
  #g1 = g1 + geom_contour(data = all, aes(x=lon,y=lat, z = t.cont), bins = 1)
  #o.variable = colnames(var)[1:(length(mean) - 1)]
  #t.month = block
  
  
  #g1 = g1 + region + coord_cartesian() + limit + ggtitle(paste0(o.variable[tvar], "_", type[1], "_"," p", j, " - p", i , "_month: ", t.month, "_hour: ", lt))
  g1 = g1 + region + coord_cartesian() + limit# + ggtitle(paste0(variable[tvar], "_", type[1], "_month: ", t.month))#, "_hour: ", lt))
  g1 = g1 + facet_wrap(~month, ncol = 4)
  ggsave(paste0("/home/panhao/mnt/master/ecmwf/plot/1103", "/", "mean_", 
                variable[ttvar], ".pdf"), g1, height = 10, width = 8.3)
  sig_table = group_by(all, month) %>% summarise(pos_sig = length(which(t.sig == "*" & mu_climate > 0)) / 261, 
                                                 neg_sig = length(which(t.sig == "*" & mu_climate < 0)) / 261)
  write.csv(sig_table, paste0("/home/panhao/mnt/master/ecmwf/table/perc_sig_", variable[ttvar], ".csv"), row.names = F)
}
```

## All kinds of plots
map.R
![](Climate%20Change%20Project%20Code%20Summary/E610A86E-EF36-4228-8C54-5B001B43D498.png)
```R
# draw the map

library(ggplot2)
library(ggmap)
library(mapproj)
## Google啊Google给我China的地图数据吧
# 这个命令需要开VPN
map1 <- get_map(location = c(lon = 116.25, lat = 38), zoom = 5, maptype = "satellite")
g0 = ggmap(map1) + #coord_fixed(ylim = c(28, 47.5), xlim = c(105, 126)) +
  theme(axis.text.x = element_text(size=rel(2),face = 'bold'),
        axis.text.y = element_text(size=rel(2),face = 'bold'),
        axis.title.x = element_text(size=rel(2),face = 'bold'),
        axis.title.y = element_text(size=rel(2),face = 'bold'))

# draw contour
path = "/Users/leon/Desktop/climate/bjgr.RData"
load(path)
bjgr1 = dplyr::filter(bjgr, is.element(bjgr$id, c(1, 26, 9, 18, 22, 11, 24, 0, 14)))
bjgr1 = data.frame(bjgr)
for(i in 1:5){
  bjgr1 = bjgr1[which(bjgr1$order %% 2 == 0), ]
  bjgr1$order = bjgr1$order / 2
}

# draw province label
province_label = c("TIANJIN", "HEBEI", "INNER MONGOLIA", "LIAO NING", "BEIJING", "SHANXI", "SHAANXI", "SHANDONG", "HENAN", "JIANGSU", "HUBEI", "ANHUI")
loc_lat = c(39.1, 38.8, 40.82, 41.8, 39.80, 37.67, 34.27, 36.25, 34.36, 33.54, 30.52, 31.86)
loc_lon = c(117.0, 115.12, 111.45, 123.38, 116.46, 112.03, 108.95, 117, 113.65, 118.78, 114.31, 117.27)
draw_lab = data.frame(province_label, loc_lat, loc_lon)
prov_lab = geom_text(aes(x = loc_lon, y = loc_lat, label = province_label), color = "white", data = draw_lab, fontface = "bold")

# add the above two to g0
region = geom_path(data=bjgr1,aes(x=long,y=lat,group=group), colour= "white", linetype = 2, size =0.8,inherit.aes=TRUE, alpha = 0.6)
g1 = g0 + region

# add box line
box = data.frame(cbind(c(112.75, 119.75, 119.75, 112.75, 112.75), c(42.75, 42.75, 32.75, 32.75, 42.75)))
colnames(box) = c("lon", "lat")
g2 = g1 + geom_path(data = box, aes(x = lon, y = lat), size = 1, color = "white")

# add station name
station = read.csv("/Users/leon/Desktop/climate/linear_model/data/location_1.csv")
my.sel = c("Beijing_Meiguodashiguan", "Dezhou_Heimajituan",
           "Handan_Kuangyuan", "Shijiazhuang_Xibeishuiyuan",
           "Jinan_Shijiancezhan", "Zhengzhou_Heyida")
labels = c("Beijing", "Shijiazhuang",
           "Handan", "Jinan",
           "Zhengzhou", "Dezhou")
library(dplyr)
my.station = filter(station, is.element(file_name, my.sel))
my.station$labels = labels 
my.station[6, 2] = my.station[6, 2] - 0.06
my.station[6, 3] = my.station[6, 3] + 0.2
my.station$lat.1 = my.station$lat + 0.5

# add longitude and latitude
#my.station$lat.1[4] = my.station$lat.1[4] + 0.5
g3 = g2 + geom_point(data = my.station, aes(x = lon, y = lat), size = 2, color = "red") +
  geom_label(data = my.station, aes(x = lon, y = lat.1, label = labels), size = 4, color = "red") +
  scale_y_continuous(breaks = c(30, 32.75, 35, 40, 42.75, 45))+
  scale_x_continuous(breaks = c(107, 110, 112.75, 115, 119.75, 124))+
  xlim(107.5, 123.5) + ylim(30, 45) + 
  #coord_fixed(xlim = c(107.5, 123.5), ylim = c(30, 45)) + 
  xlab("Longitude") + ylab("Latitude")
g3 = g3 + geom_vline(xintercept = 112.75, size = 1, color = "white", linetype = 2) + geom_vline(xintercept = 119.75, size = 1, color = "white", linetype = 2)
g3 = g3 + geom_hline(yintercept = 32.75, size = 1, color = "white", linetype = 2) + geom_hline(yintercept = 42.75, size = 1, color = "white", linetype = 2)
g3 = g3 + prov_lab

# save
ggsave("/Users/leon/Desktop/climate/climate_change/plot_new/map.pdf", g3, width = 12, height = 12)
```

## Estimate city level’s climate change effects
```r
# Estimate variance and covariance of grid point of each city

library(dplyr)
library(tidyr)
library(lubridate)
setwd("/home/panhao/mnt/data/")
dat = read.csv("combined_data.csv")

blh_bld_id = which(dat$names == "blh" | dat$names == "bld")
dat[blh_bld_id, "value"] = log(dat[blh_bld_id, "value"])

dat$month = month(dat$id)
mu_t = group_by(dat, city, names, year, month) %>% summarise(mu = mean(value))

years = seq(1979, 2016, 1)
months = seq(1, 12, 1)
vars = levels(dat$names)

my.func = function(m, mu_t){
  library(dplyr)
  library(tidyr)
  library(lubridate)
  library(boot)
  years = seq(1979, 2016, 1)
  months = seq(1, 12, 1)
  city_ls = c("Anyang","Baoding","Beijing","Binzhou","Cangzhou","Changzhi","Chengde",
              "Dezhou","Handan","Hebi","Hengshui","Heze","Jiaozuo","Jinan",
              "Jincheng","Jining","Kaifeng","Laiwu", "Langfang","Liaocheng","Puyang",
              "Qinhuangdao","Shijiazhuang","Taian", "Tangshan", "Tianjin",
              "Xinxiang","Yangquan", "Zhangjiakou","Zhengzhou","Zibo")
  setwd("/home/panhao/mnt/data/")
  dat = read.csv(sprintf("new_data/by_month_data/%02d.csv", months[m]))
  dat = merge(dat, mu_t, all.x = T)
  dat$value = dat$value - dat$mu
  dat$mu = NULL
  vars = levels(dat$names)
  for(y in 1:length(years)){
    res = NA
    if(file.exists(sprintf("/home/panhao/mnt/master/ecmwf/table/city_cov/%02d-%d.csv", months[m], years[y]))){
      next
    }
    print(sprintf("begin month %s year %s", months[m], years[y]))
    ptm = proc.time()
        tmp1 = filter(dat, year == years[y])
        tmp2 = filter(dat, year == years[y])
        
        tmp = merge(tmp1, tmp2, by = c("month", "year", "id"))
        my.boot = function(x, y){
          my.mean = function(x){
            return(mean(x[, 1] * x[, 2]) - mean(x[, 1]) * mean(x[, 2]))
          }
          app1 = tsboot(cbind(x, y), my.mean, 100, 8, sim = "geom")
          app1 = mean(app1$t)
          return(app1)
        }
        res.t = group_by(tmp, names.x, names.y, city.x, city.y) %>% summarise(cov_res = my.boot(value.x, value.y))
        num = dim(res.t)[1]
        print(proc.time() - ptm)
        if(is.na(res)){
          res = data.frame(res.t, rep(years[y], num))
          colnames(res) = c("var1", "var2", "city1", "city2", "cov", "year")
        }
        else{
          res.t = data.frame(res.t, rep(years[y], num))
          colnames(res.t) = c("var1", "var2", "city1", "city2", "cov", "year")
          res = rbind(res, res.t)
        }
    print(proc.time() - ptm)
    write.csv(res, sprintf("/home/panhao/mnt/master/ecmwf/table/city_cov/%02d-%d.csv", months[m], years[y]), row.names = F)
  }
}

library(doParallel)
cl <- makeCluster(12)
registerDoParallel(cl)
foreach(m = 1:12,.combine='rbind') %dopar% my.func(m, mu_t)
stopCluster(cl)

```
有了每个城市的variance and covariance，我们就可以估计31个城市的平均值，详情见paper中对于climate change effects的variance的推导。下面的code是其实现。这段代码实现的时候比较赶，现在看来写得不是很优雅，你可以再修改他。
```r
library(dplyr)
library(tidyr)
library(boot)
#library(bestglm)

reg = function(fit.ts){
  fit.ts = data.frame(fit.ts)
  obj_linear = lm(y~0+., data = fit.ts)
  t = summary(obj_linear)
  r2 = t$r.squared
  t = t$coefficients[, c(1, 4)]
  #t[, 2] = as.character(cut(t[, 2], breaks = c(-1, 0.001, 0.01, 0.05, 0.1, 10), labels = c('***', '**', "*", ".", " ")))
  t = rbind(t, c(r2, ""))
  rownames(t)[dim(t)[1]] = "$R^2$"
  t[, 1] = format(as.numeric(t[, 1]), digits = 1, scientific = F)
  rname = rownames(t)
  t = as.numeric(t[, 1])
  #t = paste0(t[, 1], t[, 2])
  return(t)
}

h2 = function(v){
  alpha = v[[3]]; beta = v[[4]]; mu1 = v[[1]]; mu2 = v[[2]];
  return(exp(alpha + sum(beta %*% t(mu2))))
}
h1= function(v){
  alpha = v[[3]]; beta = v[[4]]; mu1 = v[[1]]; mu2 = v[[2]];
  return(exp(alpha + sum(beta %*% t(mu1))))
}
hv = function(v){
  return(h2(v) - h1(v))
}
nabla_hv = function(v){
  alpha = v[[3]]; beta = v[[4]]; mu1 = v[[1]]; mu2 = v[[2]];
  return(unlist(c(-beta*h1(v), beta*h2(v), hv(v), mu2*h2(v) - mu1*h1(v))))
}
nabla2_hv = function(v){
  alpha = as.matrix(v[[3]]); beta = as.matrix(v[[4]]);
  mu1 = matrix(as.matrix(v[[1]]), ncol = 1); mu2 = matrix(as.matrix(v[[2]], ncol = 1), ncol = 1);
  num = length(beta)
  
  term1 = -beta %*% t(beta) * h1(v)
  term2 = diag(rep(0, num))
  term3 = -beta*h1(v)
  term4 = -(beta %*% t(beta) + diag(rep(1, num)))*h1(v)
  
  term5 = diag(rep(0, num))
  term6 = beta %*% t(beta) * h2(v)
  term7 = beta*h2(v)
  term8 = (beta %*% t(beta) + diag(rep(1, num)))*h2(v)
  
  term9 = -t(beta) * h1(v)
  term10 = t(beta) * h2(v)
  term11 = hv(v)
  term12 = t(mu2) * h2(v) - t(mu1) * h1(v)
  
  term13 = -mu1 %*% t(beta) * h1(v)
  term14 = mu2 %*% t(beta) * h2(v)
  term15 = mu2 * h2(v) - mu1 * h1(v)
  term16 = mu2 %*% t(mu2) * h2(v) - mu1 %*% t(mu1) * h1(v)
  
  ret1 = cbind(term1, term2, term3, term4)
  ret2 = cbind(term5, term6, term7, term8)
  ret3 = cbind(term9, term10, term11, term12)
  ret4 = cbind(term13, term14, term15, term16)
  
  ret = rbind(ret1, ret2, ret3, ret4)
  return(ret)
}
read.cov = function(x){
  var.use = c("sp", "t2m", "d2m", "bld", "blh", "NW", "NE", "SW", "SE")
  cov_name = c()
  for(t in var.use){
    cov_name = c(cov_name, paste0(t, "_", var.use))
  }
  x = x[, -1]
  x = x[, cov_name]
  x = matrix(x, ncol = 9)
  return(x)
}

setwd("/home/panhao/mnt/master/ecmwf/linear_data_by_city/")

#file_name = as.character(station[, 1])

city_ls = c("Anyang","Baoding","Beijing","Binzhou","Cangzhou","Changzhi","Chengde",
            "Dezhou","Handan","Hebi","Hengshui","Heze","Jiaozuo","Jinan",
            "Jincheng","Jining","Kaifeng","Laiwu", "Langfang","Liaocheng","Puyang",
            "Qinhuangdao","Shijiazhuang","Taian", "Tangshan", "Tianjin","Xingtai","Xinxiang","Yangquan",
            "Zhangjiakou","Zhengzhou","Zibo")
idx = read.csv("/home/panhao/mnt/master/ecmwf/support file/city_idx.csv")
rownames(idx) = idx$city_en
idx = idx[city_ls, 4]

file_name = dir()
file_name = unlist(strsplit(file_name, split = ".csv"))
new.data1 = list()
for(i in 1:length(file_name)){
  t = read.csv(paste0(file_name[i], ".csv"))[, -1]
  new.data1 = append(new.data1, list(t))
}

data = new.data1
for(i in 1:length(data)){
  if(i == 1)
    temp = group_by(data[[i]], month) %>% summarise(m = mean(PM2.5, na.rm = T))
  else{
    tmp = group_by(data[[i]], month) %>% summarise(m = mean(PM2.5, na.rm = T))
    temp[, 2] = temp[, 2] + tmp[, 2]
  }
}
#my.sel = seq(1, 81, 1)

reg_year = 2014
years = c(2014, 2015)
months = seq(1, 12, 1)
get.season = function(time){
  year = time[1]; month = time[2]; day = time[3]
  if((month == 11 & day >= 15) | (month >= 12)){
    return(paste0(year+1, "_", 1))
  }
  if((month == 3 & day < 15) | (month <= 2)){
    return(paste0(year, "_", 1))
  }
  if((month == 3 & day >= 15) | (month <= 5)){
    return(paste0(year, "_", 2))
  }
  if((month >= 6) & month <= 8){
    return(paste0(year, "_", 3))
  }
  if(((month >= 9) & (month <= 10)) | (month == 11 & day < 15)){
    return(paste0(year, "_", 4))
  }
}
sea = 1
reg_year = 2015
for(reg_year in c(2014, 2015, 2016)){
  for(mi in 1:length(months)){
    my.table = NA
    for(i in 1:length(city_ls)){
      test.all = data[[i]]
      print( sprintf("%d-%d-%d",reg_year, i, mi))
      test = test.all
      this.season = get.season(c(reg_year, months[mi], 16))
      season = apply(test[, 2:4], 1, get.season)
      test$season = season
      test = filter(test, season == this.season)

      time = test[, c("year", "month", "day", "hour")]
      poll = test[, c("PM2.5")]
      meteo = test[, c("sp", "bld", "blh", "t2m", "d2m", "theta", "NE", "NW", "SE", "SW", "SH")]
      colnames(meteo) = c("SP", "LogBLD", "LogBLH", "T2M", "D2M", "IPT", "INE", "INW", "ISE", "ISW", "ISH")
      
      #print(i)
      #print(cor(test$SH, test$d2m, method = "pearson", use = "pairwise.complete.obs"))
      #print(cor(test$theta, test$t2m, method = "pearson", use = "pairwise.complete.obs"))
      #next
      run = cbind((poll), meteo)
      colnames(run)[1] = "PM2.5"
      sel = which(complete.cases(run))
      sel2 = which(run[, 1] > 0)
      sel = intersect(sel, sel2)
      #run = cbind(run, c(NA, run[1:(dim(run)[1] - 1), 1]))
      #colnames(run)[dim(run)[2]] = "Lag_PM2.5"
      run = run[sel, ]
      if(dim(run)[1] < 300){
        my.table = cbind(my.table, rep(NA, 11))
        next
      }
      xxx = run[, -1]
      y = log(run[, 1])
      xxx$LogBLH = log(xxx$LogBLH)
      xxx$LogBLD = log(xxx$LogBLD)
      
      #xxx = cbind(xxx, xxx[, 8]^2)
      #xxx = cbind(xxx, xxx[, 4:5]^2)
      #colnames(xxx)[11:13] = c("NW^2", "t2m^2", "d2m^2")
      xxx = cbind(xxx, (c(NA, log(run$PM2.5)[1:(dim(run)[1] - 1)])))
      colnames(xxx)[dim(xxx)[2]] = "Lagged Y"
      #xxx = cbind(xxx, (c(NA, NA, log(run$PM2.5)[1:(dim(run)[1] - 2)])))
      #colnames(xxx)[dim(xxx)[2]] = "log(PM2.5)[2]"
      
      #xxx[, 7] = log(xxx[, 7] + 1)
      #xxx[, 8] = log(xxx[, 8] + 1)
      #xxx[, 9] = log(xxx[, 9] + 1)
      #xxx[, 10] = log(xxx[, 10] + 1)
      
      #xxx = data.frame(lapply(xxx, function(xx){(xx - min(xx))/(max(xx) - min(xx))}))
      rname = c("SP", "T2M", "D2M", "LogBLD", "LogBLH", "INW", "INE", "ISW", "ISE", "Lagged Y")
      xxx$ISH = test$ISH[sel]
      xxx$IPT = test$IPT[sel]
      xxx = as.matrix(xxx[, rname])
      
      my.read = function(x){
        tmp = read.csv(x)
        rownames(tmp) = tmp[, "region_id"]
        rownames(tmp)[64] = "Taian"
        return(tmp)
      }
      dat = data.frame(y, xxx)
      dat = dat[which(complete.cases(dat)), ]
      my.cov = function(fit.ts){
        fit.ts[1, 7:10] = fit.ts[1, 7:10] + 0.0000000001
        fit.ts = data.frame(fit.ts)
        obj_linear = lm(y~1+., data = fit.ts)
        t = summary(obj_linear)
        
        t1 = t$coefficients[1:10, 1] / (1-t$coefficients[11, 1])
        t2 = data.frame(t1 %*% t(t1))
        t2$name = colnames(t2)
        t3 = gather(t2, key = name)
        return(t3$value)
      }
      my.mean = function(fit.ts){
        fit.ts[1, 7:10] = fit.ts[1, 7:10] + 0.0000000001
        fit.ts = data.frame(fit.ts)
        obj_linear = lm(y~1+., data = fit.ts)
        t = summary(obj_linear)
        t1 = t$coefficients[1:10, 1] / (1-t$coefficients[11, 1])
        t2 = data.frame(t1)
        t2$name = colnames(t2)
        t3 = gather(t2, key = name)
        return(t3$value)
      }
      my.test = function(fit.ts){
        fit.ts[1, 7:10] = fit.ts[1, 7:10] + 0.0000000001
        fit.ts = data.frame(fit.ts)
        obj_linear = lm(y~1+., data = fit.ts)
        t = summary(obj_linear)
        t1 = t$coefficients[1:10, 1] / (1-t$coefficients[11, 1])
        return(t1)
      }
      e = tsboot(dat, my.test, 200, 4, sim = "geom")$t
      #e1 = colMeans(tsboot(dat, my.cov, 1000, 4, sim = "fixed")$t)
      #e2 = colMeans(tsboot(dat, my.mean, 1000, 4, sim = "fixed")$t)
      #cov_ab = e1 - e2 %*% t(e2)
      cov_ab = cov(e)
      obj_lm = lm(y~1+., data = data.frame(xxx))
    
      m = months[mi]
      delta = my.read(paste0("/home/panhao/mnt/master/ecmwf/table/change_linear_table_", m, ".csv"))
      delta_percent = my.read(paste0("/home/panhao/mnt/master/ecmwf/table/change_linear_table_percent_", m, ".csv"))
      #var = my.read(paste0("/home/panhao/mnt/master/ecmwf/table/change_linear_table_var_", m, ".csv"))
      #cov1 = diag(var[city_ls[i], rname[1:9]])
      #cov2 = diag(var[city_ls[i], rname[1:9]])
      
      mu1 = my.read(paste0("/home/panhao/mnt/master/ecmwf/table/change_linear_table1_", m, ".csv"))[city_ls[i], rname[-10]]
      mu2 = my.read(paste0("/home/panhao/mnt/master/ecmwf/table/change_linear_table2_", m, ".csv"))[city_ls[i], rname[-10]]
      
      cov1 = read.cov(read.csv(paste0("/home/panhao/mnt/data/cov/cov_1_", m, ".csv"))[idx[i], ])
      cov2 = read.cov(read.csv(paste0("/home/panhao/mnt/data/cov/cov_2_", m, ".csv"))[idx[i], ])
      
      var1 = cbind(cov1, matrix(rep(0, (9+10)*9), nrow = 9))
      var2 = cbind(matrix(rep(0, 9*9), nrow = 9), cov2, matrix(rep(0, 10*9), nrow = 9))
      var3 = cbind(matrix(rep(0, (9+9)*10), nrow = 10), cov_ab)
      var = matrix(rbind(var1, var2, var3))
      var = matrix(unlist(var), nrow = sqrt(length(var)))
      v = list(mu1, mu2, obj_lm$coefficients[1] / (1-obj_lm$coefficients[11]), obj_lm$coefficients[rname[-10]] / (1-obj_lm$coefficients[11]))
      #v = list(mu1, mu2, obj_lm$coefficients[1], obj_lm$coefficients[rname[-10]])
      eta = hv(v) - 0.5 * sum(diag(nabla2_hv(v) %*% var))
      var_eta = t(nabla_hv(v)) %*% var %*% nabla_hv(v)
      
      print(sprintf("%f_%f", eta, var_eta))
      #jj = 10
      #for(jj in 1:18){
      #  print(t(nabla_hv(v)[-jj]) %*% var[-jj, -jj] %*% nabla_hv(v)[-jj])
      #}
      #look = tsboot(fit.ts, reg, R = 100, l = 10, sim = "geom")
      # print(file_name[i])
      # 
      # Y1 = sum(obj_lm$coefficients[1:10] * unlist(c(1, mu1[file_name[i], rname[1:9]]))) / (1 - obj_lm$coefficients[11])
      # Y2 = sum(obj_lm$coefficients[1:10] * unlist(c(1, mu2[file_name[i], rname[1:9]]))) / (1 - obj_lm$coefficients[11])
      # change = (exp(Y2) - exp(Y1)) * sigma_term
      #
      
      # old delta
      # delta = unlist(lapply(delta[file_name[i], rname[1:9]], function(x){sprintf("%.3f",x)}))
      # delta_percent = unlist(lapply(delta_percent[file_name[i], rname[1:9]], function(x){paste0(sprintf("%.1f",x*100), "%")}))
      # del_app = paste0(delta, "(" ,delta_percent, ")")
      
      # new delta
      delta1 = v[[4]] * delta[file_name[i], rname[1:9]]
      delta1 = delta1[1, ] / sum(delta1[1, ])
      del_app = unlist(lapply(delta1, function(x){sprintf("%.3f",x)}))
      
      app = c(del_app, sprintf("%.3f",eta), sprintf("%.3f",sqrt(var_eta)))
      # 
      my.table = cbind(my.table, app)
    }
    library(stargazer)
    my.table = my.table[, -1]
    colnames(my.table) = file_name
    rownames(my.table) = c(rname[1:9], sprintf("Diff LogPM2.5 %s", reg_year), sprintf("Diff PM2.5 %s", reg_year))
    write.csv(my.table, sprintf("/home/panhao/mnt/master/ecmwf/table/change_table/%s_%s_attribution.csv", months[mi], reg_year))
  }
}

#test = data[[59]]
#test = filter(test, (test$month >= 11 | test$month <= 3))
#plot(log(test$blh[2:1816]), (test$PM2.5[2:1816]))

```


有了每个城市的climate change effects的估计和其方差的估计，我们可视化他
![](Climate%20Change%20Project%20Code%20Summary/2D80CBF7-3E74-4BBA-A172-83C263B9A6ED.png)
```r
# 对应文章中climate change effects map
library(maptools)
library(dplyr)
library(ggplot2)
loc2city = read.csv("/Users/leon/Desktop/climate/change_map/loc2city_en.csv")[, -1]
loc2city = unlist(loc2city)
lat_list = seq(32.75, 42.74, 0.5)
lon_list = seq(112.75, 119.74, 0.5)
loc_list = NA

for(lon in lon_list){
  for(lat in lat_list){
    loc_list = rbind(loc_list, c(lat, lon))
  }
}
loc_list = loc_list[-1, ]
loc2city = cbind(loc_list, as.character(loc2city))
colnames(loc2city) = c("lat", "lon", "city")

look0 = readShapePoly("/Users/leon/Desktop/climate/map/CHN_adm_shp/CHN_adm1.shp")
bjgr0 = fortify(look0)
sel = which(is.element(look0$NAME_1, c("Anhui", "Shandong",
                                       "Shanxi", "Jiangsu",
                                       "Henan", "Nei Mongol", "Liaoning")))
ID_sel = look0$ID_1[sel] - 1
bjgr0 = filter(bjgr0, is.element(id, ID_sel))
for(i in 1:5){
  bjgr0 = bjgr0[which(bjgr0$order %% 2 == 0), ]
  bjgr0$order = bjgr0$order / 2
}
#pdf("/Users/leon/Desktop/look.pdf", width = 8, height = 8)
#ggplot(bjgr0) + geom_polygon(aes(x=long,y=lat,group=group), colour = "grey", linetype = "dashed")# + coord_map("polyconic")
#dev.off()

# keep = c("Dongying", "Weifang", "Yantai", "Rizhao", "Qingdao", "Lianyungang")

look = readShapePoly("/Users/leon/Desktop/climate/map/CHN_adm_shp/CHN_adm2.shp")
bjgr = fortify(look)
for(i in 1:3){
  bjgr = bjgr[which(bjgr$order %% 2 == 0), ]
  bjgr$order = bjgr$order / 2
}
#bjgr1 = dplyr::filter(bjgr, is.element(bjgr$id, c(1, 26, 9, 18, 22, 11, 24, 0, 14)))
limit = coord_fixed(ylim = c(33, 42.5), xlim = c(113, 119.5))

length(unique(bjgr$id))
NAME_1 = look$NAME_1
NAME_2 = look$NAME_2
ID_2 = look$ID_2 - 1
sel = which(is.element(NAME_1, c("Beijing", "Anhui", "Shandong", "Shanxi", "Jiangsu", "Hebei", "Henan", "Tianjin", "Nei Mongol", "Liaoning")))
ID_2 = ID_2[sel]
NAME_2 = NAME_2[sel]
app = cbind(ID_2, as.character(NAME_2))
colnames(app) = c("id", "city")
bjgr1 = merge(bjgr, app)
bjgr1 = bjgr1[which(is.element(bjgr1$id, ID_2)), ]
bjgr1 = bjgr1[order(bjgr1$order),]

bjgr1$city = as.character(bjgr1$city)
bjgr1$city[which(bjgr1$city == "Tai'an")] = "Taian"

library(stargazer)
library(RColorBrewer)
setwd("/Users/leon/Desktop/climate/climate_change/change_table/change_table")
months = seq(1, 12, 1)
# months_name = c("Nov", "Dec", "Jan", "Feb", "Mar")
months_name = c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
years = c(2014, 2015, 2016)
mycolors<-brewer.pal(10,"Spectral")
mycolors = c(mycolors[10:6], "white", mycolors[5:1])
break.point = c(seq(-25, 25, 5))
color = mycolors
all_line = NA
for(yi in 1:length(years)){
  for(mi in 1:length(months)){
    table = read.csv(sprintf("%s_%s.csv", months[mi], years[yi]))
    row.names(table) = table[, 1]
    table = table[, -1]
    diff = as.numeric(t(table[10, ])[, 1])
    std = as.numeric(t(table[11, ])[, 1])
    app = cbind(colnames(table),diff,diff/std,std)
    colnames(app) = c("city", "diff", "t", "std")
    bjgr2 = merge(bjgr1, app, all.y = T, sort = F)
    bjgr2 = bjgr2[order(bjgr2$order),]
    bjgr2$diff = as.numeric(as.character(bjgr2$diff))
    
    sel = which(is.na(bjgr2$diff))
    if(yi != 1){
      bjgr2[sel, "diff"] = 0
    }
    bjgr2$month = mi
    if(mi == 1){
      bjgr3 = bjgr2
    }
    else{
      bjgr3 = rbind(bjgr3, bjgr2)
    }
  }
  
  {
    bjgr3$pv = (pnorm(-abs(as.numeric(as.character(bjgr3$t)))) < 0.025)
    bjgr3$alpha = as.factor(bjgr3$pv * 0.5 + 0.5)
    bjgr3$month = factor(bjgr3$month)
    levels(bjgr3$month) = months_name
    
    sig = unique(bjgr3[, c("diff", "alpha", "city", "std", "month")])
    # sea = cbind(rep(0, 12), rep(0, 12), rep("Sea", 12), months_name)
    # colnames(sea) = c("diff", "alpha", "city", "month")
    # sig = rbind(sig, sea)
    sig = merge(sig, loc2city, all.x = T)
    sig$alpha = as.character(sig$alpha)
    sig$lat = as.numeric(as.character(sig$lat))
    sig$lon = as.numeric(as.character(sig$lon))
    sig[which(sig$alpha == 0.5), "alpha"] = " "
    sig[which(sig$alpha == 1), "alpha"] = "*"
    sig$diff = as.numeric(sig$diff)
    sig[which(abs(sig$diff) > 1000), "diff"] = NA
    sig = filter(sig, !is.na(diff))
    
    city_num = length(unique(sig[, c("city")]))
    sig.1 = unique(sig[, c("diff", "month", "city", "alpha", "std")])
    sig.1$std = as.numeric(as.character(sig.1$std))
    line = group_by(sig.1, month) %>% summarise(mean_diff = mean(diff, na.rm = T),
                                                mean_std = sqrt(sum(std**2, na.rm = T)) / n(),
                                                mean_sig_std = sqrt(sum(std[which(alpha == "*")]**2, na.rm = T)) / length(which(alpha == "*")),
                                                mean_sig_diff = mean(diff[which(alpha == "*")], na.rm = T),
                                              perc_pos = length(which(alpha == "*" & diff < 0)) / city_num,
                                              perc_neg = length(which(alpha == "*" & diff > 0)) / city_num)
    line$year = years[yi]
    line$mean_std = 2.5 * line$mean_std
    all_line = rbind(all_line, line)
    
    #bjgr3.1 = filter(bjgr3, is.element(city, c(keep, as.character(unique(sig$city)))))
    bjgr3$diff[which(abs(bjgr3$diff) > 1000)] = 0
    back_ground = geom_polygon(data = bjgr0, aes(x=long,y=lat,group=group), fill = "#E6E6E6", colour = "#808080", linetype = "dashed")
    g = ggplot() + back_ground + geom_polygon(data = bjgr3, aes(x=long,y=lat,group=group,fill=diff), colour = "#333333", linetype = "solid")
    g = g + geom_text(data = sig, aes(x = lon, y = lat, label = alpha))
    
    g1 = g + scale_fill_gradientn(colors = color,limits=c(min(break.point),max(break.point))
                                  ,guide = 'colourbar',breaks=break.point) +
      #scale_colour_manual(values = c("grey", "black"), guide = 'none') + 
      scale_alpha_manual(values = c(0.5, 1), guide = 'none')
    g1 = g1 + xlab("Longitude") + ylab("Latitude") + 
      theme(axis.text.x = element_text(size=rel(1.7),face = 'bold'),
            axis.text.y = element_text(size=rel(1.7),face = 'bold'),
            axis.title.x = element_text(size=rel(2),face = 'bold'),
            axis.title.y = element_text(size=rel(2),face = 'bold'),
            legend.text = element_text(size = rel(1.5), face = 'bold'),
            #legend.title = element_text(size = rel(1), face = 'bold'),
            legend.title=element_blank(),
            legend.key.height=unit(30, "mm"),
            legend.key.width=unit(5, "mm"), #图例符号的宽度
            strip.text = element_text(size = rel(1.7), face = 'bold'),
            strip.background = element_rect(fill = "white"),
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank(),
            panel.background = element_rect(fill = "#9ecae1"))
      g1 = g1 + theme(legend.position = 'right')
      gg = g1 + coord_cartesian() + limit + facet_wrap(~month, ncol = 6)
      #pdf(sprintf("%s.pdf", years[yi]), width = 18, height = 8)
      #gg
      #dev.off()
  }
}
all_line.1 = all_line
all_line = all_line.1
all_line = all_line[-1, ]

```

```r
# draw summary plot

# read city mean file (you can compute by yourself)
city_mean = read.csv("year_month_pm25_mean.csv")
city_mean.1 = group_by(city_mean, Months, Year) %>% summarise(mu = mean(PM25, na.rm = T))
colnames(city_mean.1) = c("month", "year", "region_mean")
all_line = merge(all_line, city_mean.1)
require(ggplot2)
library(gtable)
library(grid)
all_line$year.1 = all_line$year - 2000
all_line$x = paste0(all_line$month, " ", all_line$year.1)
all_line$x = factor(all_line$x, levels = all_line$x)

all_line$month = factor(all_line$month, levels = months_name)
all_line$year = factor(all_line$year)

my.theme = theme(axis.text.x = element_text(size=rel(1.7),face = 'bold'),
                   axis.text.y = element_text(size=rel(1.7),face = 'bold'),
                   axis.title.x = element_text(size=rel(2),face = 'bold'),
                   axis.title.y = element_text(size=rel(2),face = 'bold'),
                   legend.text = element_text(size = rel(1.5), face = 'bold'),
                   #legend.title = element_text(size = rel(1), face = 'bold'),
                   legend.title=element_blank(),
                   legend.key.height=unit(10, "mm"),
                   legend.key.width=unit(10, "mm"), #图例符号的宽度
                   legend.position = 'top',
                   strip.text = element_text(size = rel(1.7), face = 'bold'),
                   strip.background = element_rect(fill = "white"),
                   panel.grid.major = element_blank(),
                   panel.grid.minor = element_blank(),
                   panel.background = element_blank())

all_line$month.1 = as.numeric(all_line$month)
all_line$month.1[which(all_line$year == 2014)] = all_line$month.1[which(all_line$year == 2014)] - 0.15
all_line$month.1[which(all_line$year == 2016)] = all_line$month.1[which(all_line$year == 2016)] + 0.15
p1 = ggplot(all_line) + geom_hline(yintercept = 0, linetype = "dashed") +
  geom_point(aes(x = month.1, y = mean_diff, color = year), size = 3.5) + 
  geom_line(aes(x = month.1, y = mean_diff, color = year, group = year), size = 2) + 
  #geom_point(aes(x = month, y = mean_sig_diff, color = year), size = 3.5, shape = 1) + 
  #geom_line(aes(x = month, y = mean_sig_diff, color = year, group = year), size = 2, linetype = "dashed") + 
  geom_errorbar(aes(x = month.1, color = year, ymin = mean_diff - 1.96 * mean_std, ymax = mean_diff + 1.96 * mean_std), width = 0.25, size = 1) + 
  scale_x_continuous(breaks = seq(1, 12, 1), labels = months_name) + 
  xlab("Month") + ylab("Average Change") + ylim(c(-12, 5)) +
  my.theme + theme(legend.position = "right") + xlab('')

p2 = ggplot(all_line) + geom_hline(yintercept = 0, linetype = "dashed") +
  geom_point(aes(x = month.1, y = mean_sig_diff, color = year), size = 3.5, shape = 1) + 
  geom_line(aes(x = month.1, y = mean_sig_diff, color = year, group = year), size = 2, linetype = "dashed") + 
  geom_errorbar(aes(x = month.1, color = year, ymin = mean_sig_diff - 1.96 * mean_sig_std, ymax = mean_sig_diff + 1.96 * mean_sig_std), width = 0.25, size = 1) + 
  scale_x_continuous(breaks = seq(1, 12, 1), labels = months_name) + 
  xlab("Month") + ylab("Average Change") + ylim(c(-12, 8)) +
  my.theme + theme(legend.position = "top") + xlab('')

# p2 = ggplot(all_line)  + geom_hline(yintercept = 0, linetype = "dashed") +
#   geom_point(aes(x = month, y = mean_sig_diff, color = year), size = 3.5) +
#   geom_line(aes(x = month, y = mean_sig_diff, color = year, group = year), size = 2) +
#   xlab("Month") + ylab("Average of Significant\n Changes in PM2.5")  + ylim(c(-12, 5)) +
#   my.theme + theme(legend.position = "none") + xlab('')

p3 = ggplot(all_line) + geom_hline(yintercept = 0, linetype = "dashed") +
  geom_point(aes(x = month, y = mean_diff / region_mean * 100, color = year), size = 3.5) + 
  geom_line(aes(x = month, y = mean_diff / region_mean * 100, color = year, group = year), size = 2) + 
  geom_point(aes(x = month, y = mean_sig_diff / region_mean * 100, color = year), size = 3.5, shape = 1) + 
  geom_line(aes(x = month, y = mean_sig_diff / region_mean * 100, color = year, group = year), size = 2, linetype = "dashed") + 
  xlab("Month") + ylab("Relative Change") + ylim(c(-12, 5)) +
  my.theme + theme(legend.position = "none") + xlab('') + 
  scale_y_continuous(breaks = c(-10, -5, 0, 5), labels = c("-10%", "-5%", "0%", "5%"),
                     limits = c(-12, 5))

# p4 = ggplot(all_line)  + geom_hline(yintercept = 0, linetype = "dashed") +
#   geom_point(aes(x = month, y = mean_sig_diff / region_mean * 100, color = year), size = 3.5) + 
#   geom_line(aes(x = month, y = mean_sig_diff / region_mean * 100, color = year, group = year), size = 2) + 
#   xlab("Month") + ylab("Average of Significant\n Relative Changes") + ylim(c(-12, 5)) +
#   my.theme + theme(legend.position = "none") + 
#   scale_y_continuous(breaks = c(-10, -5, 0, 5), labels = c("-10%", "-5%", "0%", "5%"),
#                      limits = c(-12, 5))

p5 = ggplot(all_line) + geom_bar(aes(x = month, y = perc_pos, fill = year, alpha = 0.5), position="dodge",stat="identity") +
  xlab("Month") + ylab("Percentage of \n Positive (Negtive) Effects") + my.theme + theme(legend.position = 'top') +
  ylim(c(0, 1)) + xlab('')
p6 = ggplot(all_line) + geom_bar(aes(x = month, y = perc_neg, fill = year, alpha = 0.5), position="dodge",stat="identity") + 
  xlab("Month") + ylab("Percentage of \n Positive (Negtive) Effects") + my.theme  + theme(legend.position = 'top') +
  ylim(c(1, 0)) + xlab('')

ggsave("summary_plot_1_error_with_legend.pdf", p1, width = 18, height = 6)
ggsave("summary_plot_2_error.pdf", p2, width = 18, height = 6)
# ggsave("summary_plot_2.pdf", p2, width = 18, height = 4)
ggsave("summary_plot_3.pdf", p3, width = 18, height = 6)
# ggsave("summary_plot_4.pdf", p4, width = 18, height = 4)
ggsave("summary_plot_5.pdf", p5, width = 18, height = 6)
ggsave("summary_plot_6.pdf", p6, width = 18, height = 6)

g1 <- ggplot_gtable(ggplot_build(p1))
g2 <- ggplot_gtable(ggplot_build(p2))
g3 <- ggplot_gtable(ggplot_build(p3))
pp <- c(subset(g1$layout, name == "panel", se = t:r))
grid.newpage()
g <- gtable_add_grob(g1, list(g2$grobs[[which(g2$layout$name == "panel")]], g3$grobs[[which(g3$layout$name == "panel")]]), 
                     pp$t,pp$l, pp$b, pp$l)

#axis tweaks
ia <- which(g2$layout$name == "axis-l")
ga <- g2$grobs[[ia]]
ax <- ga$children[[2]]
ax$widths <- rev(ax$widths)
ax$grobs <- rev(ax$grobs)
ax$grobs[[1]]$x <- ax$grobs[[1]]$x - unit(1, "npc") + unit(0.15, "cm")
g <- gtable_add_cols(g, g2$widths[g2$layout[ia, ]$l], length(g$widths))
g <- gtable_add_grob(g, ax, pp$t, length(g$widths) - 1, pp$b)
grid.newpage() #一定要加，表示在新增一页作图，不加图形会重叠

#pdf("summary_1.pdf", width = 18, height = 8)
grid.draw(g)

all_line_mu = group_by(all_line, month) %>% summarise(mu_diff = mean(mean_diff), mu_std = sum(mean_std) / 9)


# table
city_ls = c("Beijing", "Dezhou", "Handan", "Jinan", "Shijiazhuang", "Zhengzhou")
for(mi in 1:length(months)){
  table1 = read.csv(sprintf("%s_%s.csv", months[mi], 2014))
  table2 = read.csv(sprintf("%s_%s.csv", months[mi], 2015))
  table3 = read.csv(sprintf("%s_%s.csv", months[mi], 2016))
  rawname = as.character(table1[, 1])
  rawname[10] = "Change in 2014"
  rawname[11] = "Change in 2015"
  rawname = c(rawname, "Change in 2016")
  
  table1 = table1[, -1]
  table2 = table2[, -1]
  table3 = table3[, -1]
  table1 <- as.data.frame(lapply(table1, FUN = function(x) {sapply(x, FUN = as.character)}))
  table2 <- as.data.frame(lapply(table2, FUN = function(x) {sapply(x, FUN = as.character)}))
  table3 <- as.data.frame(lapply(table3, FUN = function(x) {sapply(x, FUN = as.character)}))
  
  var1 = t(table1)[, 11]
  var2 = t(table2)[, 11]
  var3 = t(table3)[, 11]
  
  app1 = paste0(t(table1)[, 10], " (", var1, ")")
  names(app1) = colnames(table1)
  app2 = paste0(t(table2)[, 10], " (", var2, ")")
  app3 = paste0(t(table3)[, 10], " (", var3, ")")
  
  table = table1[-10:-11, ]
  table = t(table)
  table = cbind(table, app1)
  table = cbind(table, app2)
  table = cbind(table, app3)
  table = t(table)
  
  row.names(table1) = rawname
  table = table1[, city_ls[1:3]]
  stargazer(as.matrix(table))
  table = table1[, city_ls[4:6]]
  stargazer(as.matrix(table))
}

# bar plot
library(ggplot2)
setwd("/Users/leon/Desktop/climate/climate_change/change_table/change_table")
# city_ls = c("Anyang","Baoding","Beijing","Binzhou","Cangzhou","Changzhi","Chengde",
#             "Dezhou","Handan","Hebi","Hengshui","Heze","Jiaozuo","Jinan","Jining","Kaifeng","Laiwu", "Langfang","Liaocheng","Puyang",
#             "Qinhuangdao","Shijiazhuang","Taian", "Tangshan", "Tianjin","Xingtai","Xinxiang","Yangquan",
#             "Zhangjiakou","Zhengzhou","Zibo")
city_ls = c("Beijing", "Dezhou", "Handan", "Jinan", "Shijiazhuang", "Zhengzhou")
months = seq(1, 12, 1)
# months_name = c("Nov", "Dec", "Jan", "Feb", "Mar")
months_name = c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

month_ls = c(12, 1, 3, 7, 8)
rname = c("SP", "T2M", "D2M", "LogBLD", "LogBLH", "INW", "INE", "ISW", "ISE")
for(y in c(2014, 2015, 2016))
for(c in city_ls){
  draw = NA
  for(m in month_ls){
    perc = read.csv(sprintf("%s_%s_attribution.csv", m, y))[1:9, c] * 100
    chan = read.csv(sprintf("%s_%s.csv", m, y))[1:9, c]
    chan = unlist(strsplit(as.character(chan), split = "(", fixed = T))[seq(2, 18, 2)]
    chan = unlist(strsplit(as.character(chan), split = "%", fixed = T))[seq(1, 18, 2)]
    dire = sign(as.numeric(as.character(read.csv(sprintf("%s_2015.csv", m))[10, c])))
    app = cbind(rep(months_name[m]), perc, chan, rep(dire), rname)
    draw = rbind(draw, app)
  }
  draw = draw[-1, ]
  draw[is.na(draw)]<-0
  colnames(draw) = c("Month", "Contribution", "Percentage", "Direction", "Variable")
  draw = data.frame(draw)
  draw$Month = factor(draw$Month, levels = months_name[month_ls])
  draw$Variable = factor(draw$Variable, levels = rname)
  draw$Contribution = as.numeric(as.character(draw$Contribution))
  draw$Percentage = as.numeric(as.character(draw$Percentage)) * draw$Contribution
  draw$Direction = sign(as.numeric(draw$Direction) * draw$Contribution)
  #draw[which(draw$Month == "Aug"), "Contribution"] = NA
  g1 = ggplot(data = draw) + geom_bar(aes(x = Variable, y = Contribution, fill = Direction > 0), stat = "identity") + facet_wrap(~Month, ncol = 5) +
    xlab("") + ylab("") + theme_bw() + ylim(c(-400, 400)) + 
    theme(axis.text.x = element_text(angle = 90, hjust = 1, size=rel(1.7),face = 'bold'),
          axis.text.y = element_text(size=rel(1.7),face = 'bold'),
          axis.title.x = element_text(size=rel(2),face = 'bold'),
          axis.title.y = element_text(size=rel(2),face = 'bold'),
          legend.position = "none",
          legend.key.height=unit(5, "mm"),
          legend.key.width=unit(35, "mm"), #图例符号的宽度
          strip.text = element_text(size = rel(1.7), face = 'bold'),
          strip.background = element_rect(colour=NA, fill=NA),
          panel.border = element_rect(fill = NA, colour = "black"),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
  
  ggsave(sprintf("use/%s_%s_contribution.pdf", y, c), g1, width = 15, height = 4)
  #ggsave(sprintf("use/%s_percentage.pdf", c), g2, width = 15, height = 4)
 }
```
